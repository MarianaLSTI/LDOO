/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Mariana Garza
 */
public class DataBases {
    
    String url;
    String user;
    String contra;
    String driver;
    
    public DataBases(){
        this.url = "jdbc:mysql://localhost:3306/usuarios";
        this.user = "root";
        this.contra = "18160089";
        this.driver = "con.mysql.jdbc.Driver";
    }
    
    
}
