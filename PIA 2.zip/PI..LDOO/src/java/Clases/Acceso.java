/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import java.sql.*;

/**
 *
 * @author Mariana Garza
 */
public class Acceso {
    
    DataBases db = new DataBases();
    String sql = "";
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    public Acceso(){
        
    }
    
    public int validar(String usuario, String contra){
        int nivel = 0;
        try {
            Class.forName(db.getDriver());
            con = DriverManager.getConnection(db.getUrl(), db.getUser(), db.getContra());
            sql = "select nivel from users where username='"+ usuario +"'and pass='" + contra +"'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                nivel = rs.getInt(1);
            }
            con.close();
            rs.close();
        }
        catch(SQLException e){
            return nivel;
        }
    }
}
