package Model;

public final class Nombre {
    private String Nombre;
    private String Contrasenia;
    
    public Nombre(String Nombre, String Contrasenia){
        setNombre(Nombre);
        setContrasenia(Contrasenia);
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getContrasenia() {
        return Contrasenia;
    }
    
    public void setContrasenia(String Contrasenia) {
        this.Contrasenia = Contrasenia;
    }
}