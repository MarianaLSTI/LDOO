package FactoryMethod;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mariana Garza
 */
public class PizzeriaFactory {
    public Pizzas getPizzas(String Pizzas){
        if(Pizzas == null){
            return null;
            
        }else if(Pizzas.equalsIgnoreCase("Hawaiana")){
            return new Hawaiana();
            
        }else if(Pizzas.equalsIgnoreCase("Quesos")){
            return new Quesos();
            
        } else if(Pizzas.equalsIgnoreCase("Mexicana")){
            return new Mexicana();
        }
        
      return null;
   }
}