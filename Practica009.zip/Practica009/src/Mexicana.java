package FactoryMethod;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mariana Garza
 */
public class Mexicana implements Pizzas{
    @Override
    public void Ingredientes() {
        System.out.println("Ingredientes: Guacamole, Chile morron , Queso");
    }

    @Override
    public void Masa() {
        System.out.println("Masa: clasica");
    }

    @Override
    public void Tamaño() {
        System.out.println("Tamaño: Individual");
    }
}
